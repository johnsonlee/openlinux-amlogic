#!/bin/sh
WORKDIR=`dirname $(readlink -f $0)`
SOFTLIST=$WORKDIR/software.list
LOGFILE=$WORKDIR/soft_install.log

update()
{
	SOFT=`cat $SOFTLIST`
	
	for soft in $SOFT
	do
	echo "going to download and install $soft" >> $LOGFILE
	apt-get install -y $soft
	done
}

update
